<?php
session_start();
$pageNumer = $_POST['pageNum']; 

$filename = "sourcefiles/data.json";
$rawData = file_get_contents($filename);

$dataArray = json_decode($rawData,true);

if (isset($pageNumer))
    $pageNum = $pageNumer;

$recordCount = count($dataArray);
$itemsPerPage = 3;
$maxPage = floor($recordCount / $itemsPerPage) - 1;
$firstRecordIndex = $pageNum * $itemsPerPage;
if($pageNum > 0){
    $srno = $_SESSION['lastsrno'];
}else{
    $srno=0;
}

 $i=0;
$peopleArray= [];
for ($index = $firstRecordIndex; $index < ($firstRecordIndex+$itemsPerPage); ++$index){
    if (isset($dataArray[$index])){
        $peopleArray[$i]['name'] = $dataArray[$index]['name'];
        $peopleArray[$i]['location'] = $dataArray[$index]['location'];
        $peopleArray[$i]['id'] = $srno;
        $i++;
        $srno++;
    }

}

$_SESSION['lastsrno'] = $srno;

$data = array('pageNumber'=>$pageNumer+1,'data'=>$peopleArray);
echo json_encode($data);
?>
